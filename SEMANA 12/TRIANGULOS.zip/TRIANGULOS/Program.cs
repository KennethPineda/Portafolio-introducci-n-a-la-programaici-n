﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TRIANGULOS
{
    internal class Program
    {
        static void Main()
        {
            Console.WriteLine("Ingrese la longitud del cateto A:");
            double catetoA = double.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese el ángulo opuesto al cateto A:");
            double anguloOpuestoA = double.Parse(Console.ReadLine());

            TrianguloRectangulo objTriangulo = new TrianguloRectangulo(catetoA, anguloOpuestoA);

            Console.WriteLine($"Valor de cateto A: {objTriangulo.ObtenerCatetoA():F3}");
            Console.WriteLine($"Valor de cateto B: {objTriangulo.ObtenerCatetoB():F3}");
            Console.WriteLine($"Valor de hipotenusa: {objTriangulo.ObtenerHipotenusa():F3}");
            Console.WriteLine($"Valor de ángulo opuesto de A: {objTriangulo.ObtenerAnguloOpuestoA():F3}");
            Console.WriteLine($"Valor de ángulo opuesto de B: {objTriangulo.ObtenerAnguloOpuestoB():F3}");
            Console.WriteLine($"Valor de área: {objTriangulo.ObtenerArea():F3}^2");

            Console.ReadKey();
        }
        
    }
}
