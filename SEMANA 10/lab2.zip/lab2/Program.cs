﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Motocicleta objmMoticicleta = new Motocicleta();
            objmMoticicleta.motocicleta(2019 , 1000 , "Harley Davidson ", 0.12);

            Console.WriteLine("modelo " + objmMoticicleta.Modelo + "precio " + objmMoticicleta.Precio + "marca " + objmMoticicleta.Marca + "iva " + objmMoticicleta.Iva);
            double precioiva = 1000.00 * 1.12;
            double pagoiva = precioiva - 1000.00;
            Console.WriteLine("El precio de la motocicleta sin IVA es de: Q" + objmMoticicleta.Precio);
            Console.WriteLine("El precio de la motocicleta incluyendo IVA es: Q" + precioiva);
            Console.WriteLine("El monto de IVA a pagar es de : Q" + pagoiva);
            Console.ReadLine();
            Console.ReadKey ();

        }
    }
}
