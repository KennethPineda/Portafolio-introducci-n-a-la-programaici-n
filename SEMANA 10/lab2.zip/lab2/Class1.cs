﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2
{
    internal class Motocicleta
    {
        private int modelo;
        private double precio;
        private string marca;
        private double iva;

        public int Modelo { get => modelo; set => modelo = value; }
        public double Precio { get => precio; set => precio = value; }
        public string Marca { get => marca; set => marca = value; }
        public double Iva { get => iva; set => iva = value; }

        public void motocicleta(int model, double price, string brand, double _iva) 
        {
            modelo = model;
            precio = price;
            marca = brand;  
            iva = _iva; 
        }
    }
}
