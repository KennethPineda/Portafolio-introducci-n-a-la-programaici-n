﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tarea_9_progra_parte_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingresar su cantidad de aciertos");
            double right = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Ingesar su cantidad de errores");
            double wrong = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Ingresar su cantidad de respuestas en blanco");
            double white = Convert.ToDouble(Console.ReadLine());

            double NotaFinal = Convert.ToDouble((right * 5) + (wrong * -1) + (white * 0));
            Console.WriteLine("La nota final es de " + Convert.ToString(NotaFinal));

            Console.ReadKey();
        }
    }
}
