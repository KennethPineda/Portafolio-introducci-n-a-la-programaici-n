﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarea_9_parte_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("El automovil en el año 2016 tenia un valrode Q100,000.00");
            Console.WriteLine("Durante los seis años siguientes su valor de recuperación es de Q50,000.00");
            int valueOG = 100000, recover = 50000;
            Console.WriteLine("");


            int depre = ((valueOG - recover) / 6);
            int depre1 = ((valueOG - recover) * 2) / 6;
            int depre2 = ((valueOG - recover) * 3) / 6;
            int depre3 = ((valueOG - recover) * 4) / 6;
            int depre4 = ((valueOG - recover) * 5) / 6;
            int depre5 = ((valueOG - recover) * 6) / 6;

            int valor_total = (100000 - depre);
            int valor_total1 = (100000 - depre1);
            int valor_total2 = (100000 - depre2);
            int valor_total3 = (100000 - depre3);
            int valor_total4 = (100000 - depre4);
            int valor_total5 = (100000 - depre5);

            Console.WriteLine("Las depreciaciones acumuladas durante los 6 años son:");
            Console.WriteLine("Depreciaciòn 1er año:" + depre);
            Console.WriteLine("Depreciaciòn 2er año:" + depre);
            Console.WriteLine("Depreciaciòn 3er año:" + depre);
            Console.WriteLine("Depreciaciòn 4er año:" + depre);
            Console.WriteLine("Depreciaciòn 5er año:" + depre);
            Console.WriteLine("Depreciaciòn 6er año:" + depre);
            Console.WriteLine("");

            Console.WriteLine("El valor total durante los 6 años son:");
            Console.WriteLine("Valor total 1er año:" + valor_total);
            Console.WriteLine("Valor total 2er año:" + valor_total1);
            Console.WriteLine("Valor total 3er año:" + valor_total2);
            Console.WriteLine("Valor total 4to año:" + valor_total3);
            Console.WriteLine("Valor total 5to año:" + valor_total4);
            Console.WriteLine("Valor total 6to año:" + valor_total5);

            Console.ReadKey();
        }
    }
}
