﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tarea_1_semana_11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("ingrese el primer monto");
            double monto1 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("ingrese la moneda (USD o GTQ)");
            string moneda1 = Console.ReadLine();

            Console.WriteLine("Ingrese el segundo monto");
            double monto2 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("ingrese la moneda (USD o GTQ)");
            string moneda2 = Console.ReadLine();

            Console.WriteLine("ingrese el tercer monto");
            double monto3 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("ingrese la moneda (USD o GTQ)");
            string moneda3 = Console.ReadLine();

            if (moneda1 == "USD") { monto1 *= 7.83; }

            if (moneda2 == "USD") { monto2 *= 7.83; }

            if (moneda3 == "USD") { monto2 *= 7.83; }

            Console.WriteLine("su cantidad es");

            List<double> cantidadesEnQuetzales = new List<double>();
                cantidadesEnQuetzales.Add(monto1);
                cantidadesEnQuetzales.Add(monto2);
                cantidadesEnQuetzales.Add(monto3);
            
            cantidadesEnQuetzales.Sort();
            Console.WriteLine("la candtidad de quetzales es de:");
            for (int i= 0; i <cantidadesEnQuetzales.Count; i++)
            {
                Console.WriteLine(cantidadesEnQuetzales[i] );
            }
            Console.ReadKey();
        }
    }
}
