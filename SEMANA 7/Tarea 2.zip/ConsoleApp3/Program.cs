﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Ingrese el monto de la compra: ");
        string montoCompraStr = Console.ReadLine();

        if (string.IsNullOrEmpty(montoCompraStr))
        {
            Console.WriteLine("Error: No se ingresó un monto de compra válido.");
            return;
        }

        double montoCompra;
        double.TryParse(montoCompraStr, out montoCompra);

        double descuento = 0;
        if (montoCompra < 400)
        {
            descuento = 0;
        }
        else
        {
            if (montoCompra <= 1000)
            {
                descuento = montoCompra * 0.07;
            }
            else
            {
                if (montoCompra <= 5000)
                {
                    descuento = montoCompra * 0.10;
                }
                else
                {
                    if (montoCompra <= 15000)
                    {
                        descuento = montoCompra * 0.15;
                    }
                    else
                    {
                        descuento = montoCompra * 0.25;
                    }
                }
            }
        }

        Console.Write("¿Posee un código de descuento? (S/N): ");
        string tieneCodigoDescuentoStr = Console.ReadLine();

        bool tieneCodigoDescuento = (tieneCodigoDescuentoStr == "S" || tieneCodigoDescuentoStr == "s");

        if (tieneCodigoDescuento)
        {
            descuento += montoCompra * 0.05;
        }

        double montoFinal = montoCompra - descuento;

        Console.WriteLine("El monto a pagar final es: " + montoFinal);
    }
}
